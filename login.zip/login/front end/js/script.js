function suggestplaces() {
    // Get user preferences
    const price = document.getElementById("Budget").value;
    const event = document.getElementById("occasion").value;
    const members = document.getElementById("persons").value;
    const location = document.getElementById("locality").value;
    const interests = document.getElementById("interests").value;

    // Perform route suggestion logic based on user preferences
    // Example: You can implement a routing algorithm here

    // Display suggested places in the "suggested-route" div
    const suggestedplaces = document.getElementById("suggested-places");
    suggestedRoute.innerHTML = `
        <p>Suggested places:</p>
        <ul>
            <li>Step 1: Go to Place A</li>
            <li>Step 2: Visit Place B</li>
            <li>Step 3: Attend Event C</li>
            <!-- Add more route steps as needed -->
        </ul>
    `;
}




